# Marine Pollution Monitoring and Cleanup Tracking System (MERN)

Web platform to report marine pollution (plastic, industrial discharge, oil spills) with map
location and photos, record water quality (pH, dissolved oxygen, turbidity, temperature),
manage cleanup drives, and view an indicator dashboard. Role-based access: citizen, ngo, officer, admin.

## Structure
```
marine-pollution-tracker/
├── backend/    Node + Express + MongoDB (Mongoose) REST API
└── frontend/   React (Vite) + Leaflet map + Recharts
```

## Roles
| Role | Can do |
|------|--------|
| citizen | Report incidents (own reports only visible), volunteer for cleanups |
| ngo | + add water readings, create/manage own cleanup drives |
| officer | + see all reports, change report status, add readings |
| admin | Everything, delete reports |

Officers and admins cannot self-register; they are created by `npm run seed` (or directly in the DB).

---
## 1. Run locally

Prerequisites: Node.js 18+, and MongoDB (local install or a free Atlas cluster).

### Backend
```bash
cd backend
npm install
cp .env.example .env        # then edit MONGO_URI and JWT_SECRET
npm run seed                # optional: demo users + sample data
npm run dev                 # API on http://localhost:5000
```

### Frontend
```bash
cd frontend
npm install
npm run dev                 # http://localhost:5173
```
In development the Vite dev server proxies `/api` and `/uploads` to port 5000,
so leave `VITE_API_URL` empty.

Demo logins after seeding:
- admin@marine.com / admin123
- officer@marine.com / officer123
- ngo@marine.com / ngo123
- citizen@marine.com / citizen123

---
## 2. How the three layers connect

```
React (Vercel)  --HTTPS + JWT-->  Express API (Render)  --Mongoose-->  MongoDB Atlas
   VITE_API_URL ───────────────►   CLIENT_URL (CORS)  ◄──────────────   MONGO_URI
```
- **Frontend -> Backend**: `VITE_API_URL` (frontend env var) = the backend's public URL.
- **Backend -> Frontend**: `CLIENT_URL` (backend env var) = the frontend's public URL (for CORS).
- **Backend -> Database**: `MONGO_URI` (backend env var) = the Atlas connection string.

---
## 3. Deploy

### Step A - Database (MongoDB Atlas)
1. Create a free account at https://www.mongodb.com/atlas and create a free **M0** cluster.
2. **Database Access** -> Add a database user (username + password).
3. **Network Access** -> Add IP address `0.0.0.0/0` (allows Render to connect).
4. **Connect -> Drivers** -> copy the connection string and add the database name:
   `mongodb+srv://<user>:<password>@cluster0.xxxxx.mongodb.net/marine_pollution?retryWrites=true&w=majority`
5. (Optional) Seed the cloud DB from your laptop: put this string in `backend/.env` and run `npm run seed`.

### Step B - Backend (Render)
1. Push the project to GitHub (see "Git" below).
2. On https://render.com -> **New -> Web Service** -> connect the repo.
3. Settings:
   - Root Directory: `backend`
   - Runtime: Node
   - Build Command: `npm install`
   - Start Command: `npm start`
4. **Environment variables**:
   - `MONGO_URI` = the Atlas string from Step A
   - `JWT_SECRET` = a long random string
   - `CLIENT_URL` = your frontend URL (add after Step C; you can temporarily use `http://localhost:5173`)
5. Deploy. Open `https://<your-service>.onrender.com/` - you should see `{"message":"Marine Pollution API running"}`.

### Step C - Frontend (Vercel)
1. On https://vercel.com -> **Add New -> Project** -> import the same repo.
2. Settings:
   - Root Directory: `frontend`
   - Framework: Vite (auto-detected); Build `npm run build`; Output `dist`
3. **Environment variable**: `VITE_API_URL` = `https://<your-service>.onrender.com` (no trailing slash, no `/api`)
4. Deploy. Copy the Vercel URL (e.g. `https://marine-tracker.vercel.app`).

(Netlify also works: base dir `frontend`, build `npm run build`, publish `dist`; `public/_redirects` handles routing.)

### Step D - Connect them
1. Go back to Render -> your service -> Environment -> set `CLIENT_URL` to the Vercel URL
   (multiple origins allowed, comma-separated). Save; Render redeploys.
2. Open the Vercel URL, log in with a seeded account, and submit a test report.

### Step E - Verify checklist
- [ ] `GET https://<api>/` returns the JSON message
- [ ] Browser console has no CORS errors (if it does, `CLIENT_URL` doesn't match the exact Vercel origin)
- [ ] Login works and the dashboard loads charts
- [ ] Creating a report saves and shows in the Reports table

### Common problems
| Symptom | Fix |
|---------|-----|
| CORS error | `CLIENT_URL` must exactly match the frontend origin (no trailing slash) |
| 404 on page refresh | Ensure `vercel.json` / `_redirects` is present |
| `MongoDB connection failed` | Check Atlas user/password, `0.0.0.0/0` network rule, and DB name in URI |
| First request is slow | Render free tier sleeps after inactivity; wait ~30-50 s |
| Uploaded photos disappear | Render's free disk is ephemeral. For production use Cloudinary/S3 (swap `middleware/upload.js`) or attach a Render persistent disk mounted at `backend/uploads` |
| Frontend calls hit localhost | `VITE_API_URL` is baked in at build time - set it, then redeploy the frontend |

### Git
```bash
cd marine-pollution-tracker
git init && git add . && git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<you>/marine-pollution-tracker.git
git push -u origin main
```

---
## API summary
| Method | Endpoint | Access |
|--------|----------|--------|
| POST | /api/auth/register, /api/auth/login | public |
| GET | /api/auth/me | logged in |
| GET/POST | /api/reports (multipart `photos`) | logged in |
| PATCH | /api/reports/:id/status | officer, admin |
| GET/POST | /api/water | GET: logged in, POST: officer, ngo, admin |
| GET/POST | /api/cleanups | GET: logged in, POST: ngo, officer, admin |
| POST | /api/cleanups/:id/join | logged in |
| PATCH | /api/cleanups/:id | ngo (owner), officer, admin |
| GET | /api/dashboard | logged in |

## Future scope (from the project scope slide)
IoT sensor integration and satellite-based oil spill detection.
