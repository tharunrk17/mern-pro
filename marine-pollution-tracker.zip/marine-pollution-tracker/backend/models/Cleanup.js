const mongoose = require('mongoose');

const cleanupSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, default: '' },
    report: { type: mongoose.Schema.Types.ObjectId, ref: 'Report' }, // linked pollution site
    locationName: { type: String, default: '' },
    date: { type: Date, required: true },
    status: { type: String, enum: ['planned', 'ongoing', 'completed'], default: 'planned' },
    wasteCollectedKg: { type: Number, default: 0, min: 0 },
    organizer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    volunteers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Cleanup', cleanupSchema);
