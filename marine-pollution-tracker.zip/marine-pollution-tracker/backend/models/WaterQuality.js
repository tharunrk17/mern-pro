const mongoose = require('mongoose');

const waterSchema = new mongoose.Schema(
  {
    siteName: { type: String, required: true, trim: true },
    location: { lat: Number, lng: Number },
    ph: { type: Number, required: true, min: 0, max: 14 },
    dissolvedOxygen: { type: Number, required: true, min: 0 }, // mg/L
    turbidity: { type: Number, required: true, min: 0 }, // NTU
    temperature: { type: Number, required: true }, // deg C
    date: { type: Date, default: Date.now },
    recordedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('WaterQuality', waterSchema);
