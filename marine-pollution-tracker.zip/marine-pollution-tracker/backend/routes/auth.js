const router = require('express').Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { protect } = require('../middleware/auth');

const sign = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '7d' });
const payload = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role });

// Self-registration only allows citizen or ngo. Officers/admins are created via seed or by an admin.
router.post('/register', async (req, res, next) => {
  try {
    const { name, email, password, role } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: 'All fields are required' });
    if (await User.findOne({ email })) return res.status(400).json({ message: 'Email already registered' });
    const safeRole = role === 'ngo' ? 'ngo' : 'citizen';
    const user = await User.create({ name, email, password, role: safeRole });
    res.status(201).json({ token: sign(user._id), user: payload(user) });
  } catch (e) {
    next(e);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    res.json({ token: sign(user._id), user: payload(user) });
  } catch (e) {
    next(e);
  }
});

router.get('/me', protect, (req, res) => res.json({ user: payload(req.user) }));

module.exports = router;
