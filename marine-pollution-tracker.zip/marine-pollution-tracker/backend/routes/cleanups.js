const router = require('express').Router();
const Cleanup = require('../models/Cleanup');
const { protect, allow } = require('../middleware/auth');

router.get('/', protect, async (req, res, next) => {
  try {
    const rows = await Cleanup.find()
      .populate('organizer', 'name')
      .populate('report', 'title type')
      .sort('-date');
    res.json(rows);
  } catch (e) {
    next(e);
  }
});

router.post('/', protect, allow('ngo', 'officer', 'admin'), async (req, res, next) => {
  try {
    const { title, description, report, locationName, date } = req.body;
    const cleanup = await Cleanup.create({
      title,
      description,
      report: report || undefined,
      locationName,
      date,
      organizer: req.user._id,
    });
    res.status(201).json(cleanup);
  } catch (e) {
    next(e);
  }
});

// Any logged-in user can register as a volunteer
router.post('/:id/join', protect, async (req, res, next) => {
  try {
    const cleanup = await Cleanup.findByIdAndUpdate(
      req.params.id,
      { $addToSet: { volunteers: req.user._id } },
      { new: true }
    );
    if (!cleanup) return res.status(404).json({ message: 'Cleanup not found' });
    res.json(cleanup);
  } catch (e) {
    next(e);
  }
});

// Organizer/admin/officer updates status and logs waste collected
router.patch('/:id', protect, allow('ngo', 'officer', 'admin'), async (req, res, next) => {
  try {
    const cleanup = await Cleanup.findById(req.params.id);
    if (!cleanup) return res.status(404).json({ message: 'Cleanup not found' });
    const isOwner = cleanup.organizer.equals(req.user._id);
    if (!isOwner && req.user.role === 'ngo') {
      return res.status(403).json({ message: 'Only the organizer can update this drive' });
    }
    if (req.body.status) cleanup.status = req.body.status;
    if (req.body.wasteCollectedKg !== undefined) cleanup.wasteCollectedKg = Number(req.body.wasteCollectedKg);
    await cleanup.save();
    res.json(cleanup);
  } catch (e) {
    next(e);
  }
});

module.exports = router;
