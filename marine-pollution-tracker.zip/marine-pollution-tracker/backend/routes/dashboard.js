const router = require('express').Router();
const Report = require('../models/Report');
const WaterQuality = require('../models/WaterQuality');
const Cleanup = require('../models/Cleanup');
const { protect } = require('../middleware/auth');

const DAY = 24 * 60 * 60 * 1000;

const avgDO = async (from, to) => {
  const r = await WaterQuality.aggregate([
    { $match: { date: { $gte: from, $lt: to } } },
    { $group: { _id: null, avg: { $avg: '$dissolvedOxygen' } } },
  ]);
  return r.length ? r[0].avg : null;
};

router.get('/', protect, async (req, res, next) => {
  try {
    const now = new Date();
    const [byType, byStatus, trendRaw, cleanupAgg, cleanupStatus, totalReports, recentDO, previousDO] =
      await Promise.all([
        Report.aggregate([{ $group: { _id: '$type', count: { $sum: 1 } } }]),
        Report.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
        WaterQuality.aggregate([
          {
            $group: {
              _id: { $dateToString: { format: '%Y-%m-%d', date: '$date' } },
              ph: { $avg: '$ph' },
              dissolvedOxygen: { $avg: '$dissolvedOxygen' },
              turbidity: { $avg: '$turbidity' },
              temperature: { $avg: '$temperature' },
            },
          },
          { $sort: { _id: 1 } },
        ]),
        Cleanup.aggregate([{ $group: { _id: null, totalKg: { $sum: '$wasteCollectedKg' } } }]),
        Cleanup.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
        Report.countDocuments(),
        avgDO(new Date(now - 30 * DAY), now),
        avgDO(new Date(now - 60 * DAY), new Date(now - 30 * DAY)),
      ]);

    const resolved = byStatus.find((s) => s._id === 'resolved')?.count || 0;
    let trend = 'not enough data';
    if (recentDO !== null && previousDO !== null) {
      const diff = recentDO - previousDO;
      trend = Math.abs(diff) < 0.1 ? 'stable' : diff > 0 ? 'improving' : 'worsening';
    }

    res.json({
      totalReports,
      resolvedPercent: totalReports ? Math.round((resolved / totalReports) * 100) : 0,
      reportsByType: byType.map((x) => ({ name: x._id, count: x.count })),
      reportsByStatus: byStatus.map((x) => ({ name: x._id, count: x.count })),
      waterTrend: trendRaw.slice(-30).map((x) => ({
        date: x._id,
        ph: +x.ph.toFixed(2),
        dissolvedOxygen: +x.dissolvedOxygen.toFixed(2),
        turbidity: +x.turbidity.toFixed(2),
        temperature: +x.temperature.toFixed(2),
      })),
      cleanup: {
        totalWasteKg: cleanupAgg[0]?.totalKg || 0,
        byStatus: cleanupStatus.map((x) => ({ name: x._id, count: x.count })),
      },
      indicators: {
        avgDissolvedOxygen30d: recentDO !== null ? +recentDO.toFixed(2) : null,
        waterQualityTrend: trend,
      },
    });
  } catch (e) {
    next(e);
  }
});

module.exports = router;
