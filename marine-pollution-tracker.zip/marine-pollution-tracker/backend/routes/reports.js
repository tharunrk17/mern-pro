const router = require('express').Router();
const Report = require('../models/Report');
const { protect, allow } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', protect, async (req, res, next) => {
  try {
    const { type, status } = req.query;
    const filter = {};
    if (type) filter.type = type;
    if (status) filter.status = status;
    // citizens see only their own reports; others see everything
    if (req.user.role === 'citizen') filter.reportedBy = req.user._id;
    const reports = await Report.find(filter).populate('reportedBy', 'name role').sort('-createdAt');
    res.json(reports);
  } catch (e) {
    next(e);
  }
});

router.post('/', protect, upload.array('photos', 4), async (req, res, next) => {
  try {
    const { title, type, description, severity, lat, lng, address } = req.body;
    if (!title || !type || lat === undefined || lng === undefined) {
      return res.status(400).json({ message: 'Title, type and map location are required' });
    }
    const report = await Report.create({
      title,
      type,
      description,
      severity,
      location: { lat: Number(lat), lng: Number(lng), address },
      photos: (req.files || []).map((f) => `/uploads/${f.filename}`),
      reportedBy: req.user._id,
    });
    res.status(201).json(report);
  } catch (e) {
    next(e);
  }
});

router.patch('/:id/status', protect, allow('officer', 'admin'), async (req, res, next) => {
  try {
    const report = await Report.findByIdAndUpdate(
      req.params.id,
      { status: req.body.status },
      { new: true, runValidators: true }
    );
    if (!report) return res.status(404).json({ message: 'Report not found' });
    res.json(report);
  } catch (e) {
    next(e);
  }
});

router.delete('/:id', protect, allow('admin'), async (req, res, next) => {
  try {
    await Report.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted' });
  } catch (e) {
    next(e);
  }
});

module.exports = router;
