const router = require('express').Router();
const WaterQuality = require('../models/WaterQuality');
const { protect, allow } = require('../middleware/auth');

router.get('/', protect, async (req, res, next) => {
  try {
    const filter = req.query.site ? { siteName: req.query.site } : {};
    const rows = await WaterQuality.find(filter).populate('recordedBy', 'name').sort('-date').limit(200);
    res.json(rows);
  } catch (e) {
    next(e);
  }
});

router.post('/', protect, allow('officer', 'ngo', 'admin'), async (req, res, next) => {
  try {
    const { siteName, lat, lng, ph, dissolvedOxygen, turbidity, temperature, date } = req.body;
    const row = await WaterQuality.create({
      siteName,
      location: lat !== undefined && lat !== '' ? { lat: Number(lat), lng: Number(lng) } : undefined,
      ph,
      dissolvedOxygen,
      turbidity,
      temperature,
      date: date || Date.now(),
      recordedBy: req.user._id,
    });
    res.status(201).json(row);
  } catch (e) {
    next(e);
  }
});

module.exports = router;
