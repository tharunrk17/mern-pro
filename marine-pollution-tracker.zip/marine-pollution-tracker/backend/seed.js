require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Report = require('./models/Report');
const WaterQuality = require('./models/WaterQuality');
const Cleanup = require('./models/Cleanup');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Promise.all([User.deleteMany(), Report.deleteMany(), WaterQuality.deleteMany(), Cleanup.deleteMany()]);

  const [admin, officer, ngo, citizen] = await User.create([
    { name: 'Admin', email: 'admin@marine.com', password: 'admin123', role: 'admin' },
    { name: 'Env Officer', email: 'officer@marine.com', password: 'officer123', role: 'officer' },
    { name: 'Clean Coast NGO', email: 'ngo@marine.com', password: 'ngo123', role: 'ngo' },
    { name: 'Citizen One', email: 'citizen@marine.com', password: 'citizen123', role: 'citizen' },
  ]);

  const reports = await Report.create([
    { title: 'Plastic dumping at Marina Beach', type: 'plastic', severity: 'high', status: 'cleanup_planned',
      location: { lat: 13.0500, lng: 80.2824, address: 'Marina Beach, Chennai' }, reportedBy: citizen._id },
    { title: 'Oil sheen near harbour', type: 'oil', severity: 'high', status: 'investigating',
      location: { lat: 13.0950, lng: 80.2960, address: 'Chennai Port' }, reportedBy: citizen._id },
    { title: 'Effluent discharge at Ennore creek', type: 'industrial', severity: 'medium', status: 'reported',
      location: { lat: 13.2200, lng: 80.3200, address: 'Ennore' }, reportedBy: citizen._id },
  ]);

  const rows = [];
  for (let i = 45; i >= 0; i -= 3) {
    rows.push({
      siteName: 'Marina Beach',
      location: { lat: 13.05, lng: 80.2824 },
      ph: +(7.6 + Math.random() * 0.6).toFixed(2),
      dissolvedOxygen: +(5 + (45 - i) * 0.03 + Math.random() * 0.5).toFixed(2),
      turbidity: +(12 - (45 - i) * 0.08 + Math.random()).toFixed(2),
      temperature: +(28 + Math.random() * 2).toFixed(1),
      date: new Date(Date.now() - i * 86400000),
      recordedBy: officer._id,
    });
  }
  await WaterQuality.create(rows);

  await Cleanup.create({
    title: 'Marina Beach weekend cleanup', report: reports[0]._id, locationName: 'Marina Beach',
    date: new Date(Date.now() + 5 * 86400000), organizer: ngo._id, volunteers: [citizen._id],
  });
  await Cleanup.create({
    title: 'Besant Nagar shoreline drive', locationName: 'Besant Nagar',
    date: new Date(Date.now() - 10 * 86400000), status: 'completed', wasteCollectedKg: 320, organizer: ngo._id,
  });

  console.log('Seeded. Logins: admin@marine.com/admin123, officer@marine.com/officer123, ngo@marine.com/ngo123, citizen@marine.com/citizen123');
  process.exit(0);
})();
