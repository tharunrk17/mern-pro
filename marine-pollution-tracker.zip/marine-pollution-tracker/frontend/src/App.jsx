import { Link, Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './AuthContext.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Reports from './pages/Reports.jsx';
import WaterQuality from './pages/WaterQuality.jsx';
import Cleanups from './pages/Cleanups.jsx';

function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <p className="center">Loading...</p>;
  return user ? children : <Navigate to="/login" replace />;
}

export default function App() {
  const { user, logout } = useAuth();
  return (
    <>
      <header className="nav">
        <strong>🌊 Marine Pollution Tracker</strong>
        {user && (
          <nav>
            <Link to="/">Dashboard</Link>
            <Link to="/reports">Reports</Link>
            <Link to="/water">Water Quality</Link>
            <Link to="/cleanups">Cleanups</Link>
            <span className="badge">{user.name} ({user.role})</span>
            <button onClick={logout}>Logout</button>
          </nav>
        )}
      </header>
      <main className="container">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/" element={<Protected><Dashboard /></Protected>} />
          <Route path="/reports" element={<Protected><Reports /></Protected>} />
          <Route path="/water" element={<Protected><WaterQuality /></Protected>} />
          <Route path="/cleanups" element={<Protected><Cleanups /></Protected>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </>
  );
}
