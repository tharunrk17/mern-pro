import { CircleMarker, MapContainer, Popup, TileLayer, useMapEvents } from 'react-leaflet';

const COLORS = { plastic: '#2563eb', oil: '#111827', industrial: '#d97706' };
const DEFAULT_CENTER = [13.05, 80.28]; // Chennai coast; change as needed

function ClickHandler({ onPick }) {
  useMapEvents({ click: (e) => onPick && onPick(e.latlng.lat, e.latlng.lng) });
  return null;
}

// Shows report markers; if onPick is given, clicking the map selects a location.
export default function MapView({ reports = [], picked, onPick }) {
  return (
    <MapContainer center={picked ? [picked.lat, picked.lng] : DEFAULT_CENTER} zoom={10} className="map">
      <TileLayer
        attribution='&copy; OpenStreetMap contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <ClickHandler onPick={onPick} />
      {reports.map((r) => (
        <CircleMarker
          key={r._id}
          center={[r.location.lat, r.location.lng]}
          radius={9}
          pathOptions={{ color: COLORS[r.type], fillOpacity: 0.7 }}
        >
          <Popup>
            <b>{r.title}</b>
            <br />
            {r.type} - {r.status}
          </Popup>
        </CircleMarker>
      ))}
      {picked && (
        <CircleMarker center={[picked.lat, picked.lng]} radius={10} pathOptions={{ color: '#dc2626' }} />
      )}
    </MapContainer>
  );
}
