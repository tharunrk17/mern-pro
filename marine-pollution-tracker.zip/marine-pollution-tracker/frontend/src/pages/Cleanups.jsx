import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext.jsx';

export default function Cleanups() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]);
  const [reports, setReports] = useState([]);
  const [form, setForm] = useState({ title: '', description: '', locationName: '', date: '', report: '' });
  const [msg, setMsg] = useState({ text: '', ok: true });
  const canCreate = ['ngo', 'officer', 'admin'].includes(user.role);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const load = () => api.get('/cleanups').then((r) => setRows(r.data)).catch((e) => setMsg({ text: errMsg(e), ok: false }));
  useEffect(() => {
    load();
    if (canCreate) api.get('/reports').then((r) => setReports(r.data));
  }, []);

  const create = async (e) => {
    e.preventDefault();
    try {
      await api.post('/cleanups', form);
      setForm({ title: '', description: '', locationName: '', date: '', report: '' });
      setMsg({ text: 'Cleanup drive created', ok: true });
      load();
    } catch (err) {
      setMsg({ text: errMsg(err), ok: false });
    }
  };

  const join = async (id) => { await api.post(`/cleanups/${id}/join`); load(); };
  const update = async (id, body) => { await api.patch(`/cleanups/${id}`, body); load(); };
  const logWaste = (c) => {
    const kg = window.prompt('Waste collected (kg):', c.wasteCollectedKg);
    if (kg !== null && !isNaN(kg)) update(c._id, { wasteCollectedKg: kg });
  };

  return (
    <>
      {canCreate && (
        <div className="card">
          <h2>Plan a cleanup drive</h2>
          <form className="form" onSubmit={create}>
            <input placeholder="Title" value={form.title} onChange={set('title')} required />
            <div className="row">
              <input placeholder="Location name" value={form.locationName} onChange={set('locationName')} />
              <input type="date" value={form.date} onChange={set('date')} required />
            </div>
            <select value={form.report} onChange={set('report')}>
              <option value="">Link to a pollution report (optional)</option>
              {reports.map((r) => <option key={r._id} value={r._id}>{r.title}</option>)}
            </select>
            <textarea rows={2} placeholder="Description" value={form.description} onChange={set('description')} />
            {msg.text && <p className={msg.ok ? 'success' : 'error'}>{msg.text}</p>}
            <button>Create drive</button>
          </form>
        </div>
      )}
      <div className="grid">
        {rows.map((c) => {
          const joined = c.volunteers.includes(user.id);
          return (
            <div className="card" key={c._id}>
              <h3>{c.title}</h3>
              <p><span className={`tag ${c.status}`}>{c.status}</span> {new Date(c.date).toLocaleDateString()}</p>
              <p>{c.locationName}</p>
              {c.report && <p><small>Linked report: {c.report.title}</small></p>}
              <p>Organizer: {c.organizer?.name}<br />Volunteers: {c.volunteers.length}<br />Waste collected: <b>{c.wasteCollectedKg} kg</b></p>
              <div className="row">
                {!joined ? <button onClick={() => join(c._id)}>Volunteer</button> : <span className="success">You're registered ✓</span>}
                {canCreate && (
                  <>
                    <select value={c.status} onChange={(e) => update(c._id, { status: e.target.value })}>
                      <option value="planned">planned</option><option value="ongoing">ongoing</option><option value="completed">completed</option>
                    </select>
                    <button className="secondary" onClick={() => logWaste(c)}>Log waste</button>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
      {!rows.length && <p>No cleanup drives yet.</p>}
    </>
  );
}
