import { useEffect, useState } from 'react';
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import api, { errMsg } from '../api';

export default function Dashboard() {
  const [d, setD] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/dashboard').then((r) => setD(r.data)).catch((e) => setError(errMsg(e)));
  }, []);

  if (error) return <p className="error">{error}</p>;
  if (!d) return <p className="center">Loading dashboard...</p>;

  return (
    <>
      <div className="grid">
        <div className="card"><div>Total reports</div><div className="stat">{d.totalReports}</div></div>
        <div className="card"><div>Resolved</div><div className="stat">{d.resolvedPercent}%</div></div>
        <div className="card"><div>Waste collected</div><div className="stat">{d.cleanup.totalWasteKg} kg</div></div>
        <div className="card">
          <div>Water quality trend (30d)</div>
          <div className="stat" style={{ textTransform: 'capitalize' }}>{d.indicators.waterQualityTrend}</div>
          <small>Avg DO: {d.indicators.avgDissolvedOxygen30d ?? 'n/a'} mg/L</small>
        </div>
      </div>

      <div className="grid">
        <div className="card">
          <h3>Reports by type</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={d.reportsByType}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey="count" fill="#0b5c8a" /></BarChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <h3>Reports by status</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={d.reportsByStatus}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey="count" fill="#16a34a" /></BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <h3>Water quality trends</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={d.waterTrend}>
            <CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" /><YAxis /><Tooltip /><Legend />
            <Line type="monotone" dataKey="ph" stroke="#8884d8" dot={false} />
            <Line type="monotone" dataKey="dissolvedOxygen" name="Dissolved O₂" stroke="#16a34a" dot={false} />
            <Line type="monotone" dataKey="turbidity" stroke="#d97706" dot={false} />
            <Line type="monotone" dataKey="temperature" stroke="#dc2626" dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </>
  );
}
