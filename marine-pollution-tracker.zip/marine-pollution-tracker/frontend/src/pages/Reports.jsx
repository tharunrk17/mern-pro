import { useEffect, useState } from 'react';
import api, { API_ORIGIN, errMsg } from '../api';
import { useAuth } from '../AuthContext.jsx';
import MapView from '../components/MapView.jsx';

const STATUSES = ['reported', 'investigating', 'cleanup_planned', 'resolved'];

export default function Reports() {
  const { user } = useAuth();
  const [reports, setReports] = useState([]);
  const [filter, setFilter] = useState({ type: '', status: '' });
  const [form, setForm] = useState({ title: '', type: 'plastic', severity: 'medium', description: '', address: '' });
  const [picked, setPicked] = useState(null);
  const [files, setFiles] = useState([]);
  const [msg, setMsg] = useState({ text: '', ok: true });
  const canManage = ['officer', 'admin'].includes(user.role);

  const load = () =>
    api.get('/reports', { params: filter }).then((r) => setReports(r.data)).catch((e) => setMsg({ text: errMsg(e), ok: false }));
  useEffect(() => { load(); }, [filter]);

  const submit = async (e) => {
    e.preventDefault();
    if (!picked) return setMsg({ text: 'Click on the map to choose the pollution location', ok: false });
    const fd = new FormData();
    Object.entries(form).forEach(([k, v]) => fd.append(k, v));
    fd.append('lat', picked.lat);
    fd.append('lng', picked.lng);
    Array.from(files).forEach((f) => fd.append('photos', f));
    try {
      await api.post('/reports', fd);
      setMsg({ text: 'Report submitted', ok: true });
      setForm({ title: '', type: 'plastic', severity: 'medium', description: '', address: '' });
      setPicked(null);
      setFiles([]);
      e.target.reset();
      load();
    } catch (err) {
      setMsg({ text: errMsg(err), ok: false });
    }
  };

  const updateStatus = async (id, status) => {
    await api.patch(`/reports/${id}/status`, { status });
    load();
  };

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <>
      <div className="card">
        <h2>Report a pollution incident</h2>
        <form className="form" onSubmit={submit}>
          <input placeholder="Title" value={form.title} onChange={set('title')} required />
          <div className="row">
            <select value={form.type} onChange={set('type')}>
              <option value="plastic">Plastic dumping</option>
              <option value="industrial">Industrial discharge</option>
              <option value="oil">Oil spill</option>
            </select>
            <select value={form.severity} onChange={set('severity')}>
              <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option>
            </select>
          </div>
          <input placeholder="Address / landmark (optional)" value={form.address} onChange={set('address')} />
          <textarea rows={3} placeholder="Description" value={form.description} onChange={set('description')} />
          <label>Click the map to set location {picked && `(${picked.lat.toFixed(4)}, ${picked.lng.toFixed(4)})`}</label>
          <MapView reports={reports} picked={picked} onPick={(lat, lng) => setPicked({ lat, lng })} />
          <input type="file" accept="image/*" multiple onChange={(e) => setFiles(e.target.files)} />
          {msg.text && <p className={msg.ok ? 'success' : 'error'}>{msg.text}</p>}
          <button>Submit report</button>
        </form>
      </div>

      <div className="card">
        <h2>Reports</h2>
        <div className="row">
          <select value={filter.type} onChange={(e) => setFilter({ ...filter, type: e.target.value })}>
            <option value="">All types</option><option value="plastic">Plastic</option><option value="industrial">Industrial</option><option value="oil">Oil</option>
          </select>
          <select value={filter.status} onChange={(e) => setFilter({ ...filter, status: e.target.value })}>
            <option value="">All statuses</option>
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <table>
          <thead><tr><th>Title</th><th>Type</th><th>Severity</th><th>Status</th><th>Photos</th><th>By</th></tr></thead>
          <tbody>
            {reports.map((r) => (
              <tr key={r._id}>
                <td>{r.title}<br /><small>{r.location.address}</small></td>
                <td><span className={`tag ${r.type}`}>{r.type}</span></td>
                <td><span className={`tag ${r.severity}`}>{r.severity}</span></td>
                <td>
                  {canManage ? (
                    <select value={r.status} onChange={(e) => updateStatus(r._id, e.target.value)}>
                      {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  ) : <span className={`tag ${r.status}`}>{r.status}</span>}
                </td>
                <td className="thumbs">{r.photos.map((p) => <a key={p} href={`${API_ORIGIN}${p}`} target="_blank" rel="noreferrer"><img src={`${API_ORIGIN}${p}`} alt="" /></a>)}</td>
                <td>{r.reportedBy?.name}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!reports.length && <p>No reports found.</p>}
      </div>
    </>
  );
}
