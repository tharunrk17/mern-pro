import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext.jsx';

const empty = { siteName: '', ph: '', dissolvedOxygen: '', turbidity: '', temperature: '', date: '' };

export default function WaterQuality() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(empty);
  const [msg, setMsg] = useState({ text: '', ok: true });
  const canAdd = ['officer', 'ngo', 'admin'].includes(user.role);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const load = () => api.get('/water').then((r) => setRows(r.data)).catch((e) => setMsg({ text: errMsg(e), ok: false }));
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/water', form);
      setForm(empty);
      setMsg({ text: 'Reading saved', ok: true });
      load();
    } catch (err) {
      setMsg({ text: errMsg(err), ok: false });
    }
  };

  return (
    <>
      {canAdd && (
        <div className="card">
          <h2>Add water quality reading</h2>
          <form className="form" onSubmit={submit}>
            <input placeholder="Monitoring site name" value={form.siteName} onChange={set('siteName')} required />
            <div className="row">
              <input type="number" step="0.01" min="0" max="14" placeholder="pH" value={form.ph} onChange={set('ph')} required />
              <input type="number" step="0.01" min="0" placeholder="Dissolved O₂ (mg/L)" value={form.dissolvedOxygen} onChange={set('dissolvedOxygen')} required />
              <input type="number" step="0.01" min="0" placeholder="Turbidity (NTU)" value={form.turbidity} onChange={set('turbidity')} required />
              <input type="number" step="0.1" placeholder="Temperature (°C)" value={form.temperature} onChange={set('temperature')} required />
            </div>
            <input type="date" value={form.date} onChange={set('date')} />
            {msg.text && <p className={msg.ok ? 'success' : 'error'}>{msg.text}</p>}
            <button>Save reading</button>
          </form>
        </div>
      )}
      <div className="card">
        <h2>Readings</h2>
        <table>
          <thead><tr><th>Date</th><th>Site</th><th>pH</th><th>DO (mg/L)</th><th>Turbidity</th><th>Temp °C</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r._id}>
                <td>{new Date(r.date).toLocaleDateString()}</td><td>{r.siteName}</td>
                <td>{r.ph}</td><td>{r.dissolvedOxygen}</td><td>{r.turbidity}</td><td>{r.temperature}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!rows.length && <p>No readings yet.</p>}
      </div>
    </>
  );
}
